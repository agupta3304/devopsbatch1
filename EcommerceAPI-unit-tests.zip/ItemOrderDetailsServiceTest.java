package com.code.api.services;

import com.code.api.models.ItemOrderDetails;
import com.code.api.reposatories.IOrderDetailsReposatory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ItemOrderDetailsServiceTest {

    @Mock
    private IOrderDetailsReposatory orderDetailsReposatory;

    @InjectMocks
    private ItemOrderDetailsService itemOrderDetailsService;

    private ItemOrderDetails details;

    @BeforeEach
    void setUp() {
        details = new ItemOrderDetails();
        details.setItemorderid(1);
        details.setProductname("Wireless Mouse");
        details.setQty(2);
        details.setPrice(499.0);
    }

    @Test
    void testAdd_savesAndReturnsDetails() {
        when(orderDetailsReposatory.save(details)).thenReturn(details);

        ItemOrderDetails result = itemOrderDetailsService.add(details);

        assertNotNull(result);
        assertEquals("Wireless Mouse", result.getProductname());
        verify(orderDetailsReposatory, times(1)).save(details);
    }

    @Test
    void testUpdate_savesAndReturnsUpdatedDetails() {
        details.setQty(5);
        when(orderDetailsReposatory.save(details)).thenReturn(details);

        ItemOrderDetails result = itemOrderDetailsService.update(details);

        assertEquals(5, result.getQty());
        verify(orderDetailsReposatory, times(1)).save(details);
    }

    @Test
    void testDeleteById_whenFound_deletesAndReturnsMessage() {
        when(orderDetailsReposatory.findById(1)).thenReturn(Optional.of(details));
        doNothing().when(orderDetailsReposatory).delete(details);

        String result = itemOrderDetailsService.delete(1);

        assertEquals("Record is deleted", result);
        verify(orderDetailsReposatory, times(1)).delete(details);
    }

    @Test
    void testGetAll_returnsListOfDetails() {
        ItemOrderDetails details2 = new ItemOrderDetails();
        details2.setItemorderid(2);
        when(orderDetailsReposatory.findAll()).thenReturn(Arrays.asList(details, details2));

        List<ItemOrderDetails> result = itemOrderDetailsService.getAll();

        assertEquals(2, result.size());
        verify(orderDetailsReposatory, times(1)).findAll();
    }

    @Test
    void testGetByOrderId_returnsMatchingDetails() {
        when(orderDetailsReposatory.findByOrderId(1)).thenReturn(details);

        ItemOrderDetails result = itemOrderDetailsService.getByOrderId(1);

        assertNotNull(result);
        assertEquals("Wireless Mouse", result.getProductname());
        verify(orderDetailsReposatory, times(1)).findByOrderId(1);
    }
}
