package com.code.api.services;

import com.code.api.models.Category;
import com.code.api.reposatories.ICategoryReposatory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CategoryServiceTest {

    @Mock
    private ICategoryReposatory categoryRepo;

    @InjectMocks
    private CategoryService categoryService;

    private Category category;

    @BeforeEach
    void setUp() {
        category = new Category("Electronics", "Electronic gadgets and devices");
    }

    @Test
    void testCreateCategory_savesAndReturnsCategory() {
        when(categoryRepo.save(category)).thenReturn(category);

        Category result = categoryService.creatCategory(category);

        assertNotNull(result);
        assertEquals("Electronics", result.getCatname());
        verify(categoryRepo, times(1)).save(category);
    }

    @Test
    void testUpdateCategory_savesAndReturnsUpdatedCategory() {
        category.setCatdesc("Updated description");
        when(categoryRepo.save(category)).thenReturn(category);

        Category result = categoryService.updateCategory(category);

        assertEquals("Updated description", result.getCatdesc());
        verify(categoryRepo, times(1)).save(category);
    }

    @Test
    void testDeleteCategory_whenFound_deletesAndReturnsSuccessMessage() {
        when(categoryRepo.findById(1)).thenReturn(Optional.of(category));
        doNothing().when(categoryRepo).delete(category);

        String result = categoryService.deleteCategory(1);

        assertEquals("Category is deleted Successfully", result);
        verify(categoryRepo, times(1)).delete(category);
    }

    @Test
    void testDeleteCategory_whenNotFound_returnsNotFoundMessage() {
        when(categoryRepo.findById(99)).thenReturn(Optional.empty());

        String result = categoryService.deleteCategory(99);

        assertEquals("Category with 99 not found", result);
        verify(categoryRepo, never()).delete(any(Category.class));
    }

    @Test
    void testGetAllCategory_returnsListOfCategories() {
        Category c2 = new Category("Books", "Books and literature");
        when(categoryRepo.findAll()).thenReturn(Arrays.asList(category, c2));

        List<Category> result = categoryService.getAllCategory();

        assertEquals(2, result.size());
        verify(categoryRepo, times(1)).findAll();
    }
}
