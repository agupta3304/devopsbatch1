package com.code.api.services;

import com.code.api.models.Payments;
import com.code.api.reposatories.IPaymentReposatory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PaymentsServiceTest {

    @Mock
    private IPaymentReposatory paymentReposatory;

    @InjectMocks
    private PaymentsService paymentsService;

    private Payments payment;

    @BeforeEach
    void setUp() {
        payment = new Payments();
        payment.setId(1);
        payment.setRazorpayPaymentId("pay_123");
        payment.setAmount(999.0);
        payment.setStatus("SUCCESS");
    }

    @Test
    void testCreatePayment_savesAndReturnsPayment() {
        when(paymentReposatory.save(payment)).thenReturn(payment);

        Payments result = paymentsService.creatPayment(payment);

        assertNotNull(result);
        assertEquals("pay_123", result.getRazorpayPaymentId());
        verify(paymentReposatory, times(1)).save(payment);
    }

    @Test
    void testGetPaymentById_whenFound_returnsPayment() {
        when(paymentReposatory.findById(1)).thenReturn(Optional.of(payment));

        Payments result = paymentsService.getPaymentById(1);

        assertNotNull(result);
        assertEquals(999.0, result.getAmount());
        verify(paymentReposatory, times(1)).findById(1);
    }

    @Test
    void testGetPaymentById_whenNotFound_throwsException() {
        when(paymentReposatory.findById(42)).thenReturn(Optional.empty());

        assertThrows(NoSuchElementException.class, () -> paymentsService.getPaymentById(42));
    }

    @Test
    void testGetAllPayments_returnsListOfPayments() {
        Payments payment2 = new Payments();
        payment2.setId(2);
        when(paymentReposatory.findAll()).thenReturn(Arrays.asList(payment, payment2));

        List<Payments> result = paymentsService.getAllPayments();

        assertEquals(2, result.size());
        verify(paymentReposatory, times(1)).findAll();
    }

    @Test
    void testGetAllPayments_whenNoneExist_returnsEmptyList() {
        when(paymentReposatory.findAll()).thenReturn(Collections.emptyList());

        List<Payments> result = paymentsService.getAllPayments();

        assertTrue(result.isEmpty());
        verify(paymentReposatory, times(1)).findAll();
    }
}
