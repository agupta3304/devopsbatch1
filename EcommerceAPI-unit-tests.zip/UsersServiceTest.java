package com.code.api.services;

import com.code.api.models.Users;
import com.code.api.reposatories.IUsersrepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class UsersServiceTest {

    @Mock
    private IUsersrepository usersrepository;

    @InjectMocks
    private UsersService usersService;

    private Users user;

    @BeforeEach
    void setUp() {
        user = new Users("Alice", "alice@example.com", "secret123", "USER");
    }

    @Test
    void testCreateUsers_savesAndReturnsUser() {
        when(usersrepository.save(user)).thenReturn(user);

        Users result = usersService.createUsers(user);

        assertNotNull(result);
        assertEquals("alice@example.com", result.getEmailid());
        verify(usersrepository, times(1)).save(user);
    }

    @Test
    void testDeleteUsersById_whenFound_deletesAndReturnsSuccessMessage() {
        when(usersrepository.findById(1)).thenReturn(Optional.of(user));
        doNothing().when(usersrepository).delete(user);

        String result = usersService.deleteUsers(1);

        assertEquals("User is deleted Successfully", result);
        verify(usersrepository, times(1)).delete(user);
    }

    @Test
    void testDeleteUsersById_whenNotFound_returnsNotFoundMessage() {
        when(usersrepository.findById(99)).thenReturn(Optional.empty());

        String result = usersService.deleteUsers(99);

        assertEquals("User is not found with ID:99", result);
        verify(usersrepository, never()).delete(any(Users.class));
    }

    @Test
    void testGetAll_returnsListOfUsers() {
        Users user2 = new Users("Bob", "bob@example.com", "pass456", "ADMIN");
        when(usersrepository.findAll()).thenReturn(Arrays.asList(user, user2));

        List<Users> result = usersService.getAll();

        assertEquals(2, result.size());
        verify(usersrepository, times(1)).findAll();
    }

    @Test
    void testValidateUsers_withCorrectCredentials_returnsUser() {
        when(usersrepository.findByEmailid("alice@example.com")).thenReturn(user);

        Users result = usersService.validateUsers("alice@example.com", "secret123");

        assertNotNull(result);
        assertEquals("Alice", result.getName());
    }
}
