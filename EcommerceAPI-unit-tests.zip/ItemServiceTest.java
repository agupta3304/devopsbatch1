package com.code.api.services;

import com.code.api.models.Item;
import com.code.api.reposatories.IItemReposatory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ItemServiceTest {

    @Mock
    private IItemReposatory itemReposatory;

    @InjectMocks
    private ItemService itemService;

    private Item item;

    @BeforeEach
    void setUp() {
        item = new Item();
        item.setItemId(1);
        item.setItemName("Wireless Mouse");
        item.setItemPrice(499);
    }

    @Test
    void testAddItem_savesAndReturnsItem() {
        when(itemReposatory.save(item)).thenReturn(item);

        Item result = itemService.add(item);

        assertNotNull(result);
        assertEquals("Wireless Mouse", result.getItemName());
        verify(itemReposatory, times(1)).save(item);
    }

    @Test
    void testUpdateItem_savesAndReturnsUpdatedItem() {
        item.setItemPrice(599);
        when(itemReposatory.save(item)).thenReturn(item);

        Item result = itemService.update(item);

        assertEquals(599, result.getItemPrice());
        verify(itemReposatory, times(1)).save(item);
    }

    @Test
    void testDeleteItemById_whenFound_deletesAndReturnsSuccessMessage() {
        when(itemReposatory.findById(1)).thenReturn(Optional.of(item));
        doNothing().when(itemReposatory).delete(item);

        String result = itemService.delete(1);

        assertEquals("Record is deleted sucessfully", result);
        verify(itemReposatory, times(1)).delete(item);
    }

    @Test
    void testDeleteItemById_whenNotFound_returnsNotFoundMessage() {
        when(itemReposatory.findById(42)).thenReturn(Optional.empty());

        String result = itemService.delete(42);

        assertEquals("Item with Id 42 not found", result);
        verify(itemReposatory, never()).delete(any(Item.class));
    }

    @Test
    void testGetAllItems_returnsListOfItems() {
        Item item2 = new Item();
        item2.setItemId(2);
        item2.setItemName("Keyboard");
        when(itemReposatory.findAll()).thenReturn(Arrays.asList(item, item2));

        List<Item> result = itemService.getAll();

        assertEquals(2, result.size());
        verify(itemReposatory, times(1)).findAll();
    }
}
