package com.code.api.services;

import com.code.api.models.ItemOrder;
import com.code.api.reposatories.IOrdersReposatory;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class ItemOrderServiceTest {

    @Mock
    private IOrdersReposatory ordersReposatory;

    @InjectMocks
    private ItemOrderService itemOrderService;

    private ItemOrder order;

    @BeforeEach
    void setUp() {
        order = new ItemOrder();
        order.setOrderid(1);
        order.setOrderdate("2026-08-07");
        order.setTotalamount(1500.0);
        order.setRazorpayOrderId("rzp_order_123");
    }

    @Test
    void testAddOrder_savesAndReturnsOrder() {
        when(ordersReposatory.save(order)).thenReturn(order);

        ItemOrder result = itemOrderService.add(order);

        assertNotNull(result);
        assertEquals(1500.0, result.getTotalamount());
        verify(ordersReposatory, times(1)).save(order);
    }

    @Test
    void testUpdateOrder_savesAndReturnsUpdatedOrder() {
        order.setStatus("Completed");
        when(ordersReposatory.save(order)).thenReturn(order);

        ItemOrder result = itemOrderService.update(order);

        assertEquals("Completed", result.getStatus());
        verify(ordersReposatory, times(1)).save(order);
    }

    @Test
    void testDeleteOrderByObject_deletesAndReturnsMessage() {
        doNothing().when(ordersReposatory).delete(order);

        String result = itemOrderService.delete(order);

        assertEquals("Record is deletd", result);
        verify(ordersReposatory, times(1)).delete(order);
    }

    @Test
    void testGetAllOrders_returnsListOfOrders() {
        ItemOrder order2 = new ItemOrder();
        order2.setOrderid(2);
        when(ordersReposatory.findAll()).thenReturn(Arrays.asList(order, order2));

        List<ItemOrder> result = itemOrderService.getAll();

        assertEquals(2, result.size());
        verify(ordersReposatory, times(1)).findAll();
    }

    @Test
    void testGetRazorpayOrderId_returnsMatchingOrder() {
        when(ordersReposatory.findByRazorpayOrderId("rzp_order_123")).thenReturn(order);

        ItemOrder result = itemOrderService.getRazorpayOrderId("rzp_order_123");

        assertNotNull(result);
        assertEquals("rzp_order_123", result.getRazorpayOrderId());
        verify(ordersReposatory, times(1)).findByRazorpayOrderId("rzp_order_123");
    }
}
